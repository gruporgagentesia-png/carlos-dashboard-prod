"""
Vistas para Carlos AI Dashboard - PRODUCCIÓN
Conectado a Google Sheets: Datamart_GrupoRG_CarlosAI
"""

from django.shortcuts import render
from django.http import JsonResponse
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views.decorators.http import require_http_methods
import json
import logging

from .services import GoogleSheetsService, MetricasService, WebhookService

logger = logging.getLogger(__name__)


class DashboardView(View):
    """Vista principal del dashboard"""
    
    def get(self, request):
        """Renderiza el dashboard principal"""
        try:
            # Obtener datos para el contexto inicial
            metricas = MetricasService.get_metricas_principales()
            
            context = {
                'title': 'Carlos AI Dashboard - Producción',
                'metricas': metricas,
                'google_sheet_name': 'Datamart_GrupoRG_CarlosAI',
                'sheet_tab': 'Datamart_GrupoRG'
            }
            
            return render(request, 'dashboard/dashboard.html', context)
        
        except Exception as e:
            logger.error(f"Error en DashboardView: {e}")
            context = {
                'title': 'Carlos AI Dashboard - Error',
                'error': 'Error cargando datos del dashboard'
            }
            return render(request, 'dashboard/error.html', context)


class ApiMetricasView(View):
    """API para obtener métricas en tiempo real"""
    
    def get(self, request):
        """Devuelve todas las métricas del dashboard en JSON"""
        try:
            # Métricas principales
            metricas_principales = MetricasService.get_metricas_principales()
            
            # Distribución de rangos de ingresos
            rangos_ingresos = MetricasService.get_distribucion_rangos_ingresos()
            
            # Estado de hipoteca
            estado_hipoteca = MetricasService.get_estado_hipoteca()
            
            # Embudo de estados
            embudo_estados = MetricasService.get_embudo_estados()
            
            # Conversaciones por día
            conversaciones_por_dia = MetricasService.get_conversaciones_por_dia()
            
            respuesta = {
                'status': 'success',
                'data': {
                    'metricas_principales': metricas_principales,
                    'rangos_ingresos': rangos_ingresos,
                    'estado_hipoteca': estado_hipoteca,
                    'embudo_estados': embudo_estados,
                    'conversaciones_por_dia': conversaciones_por_dia,
                    'timestamp': timezone.now().isoformat()
                }
            }
            
            return JsonResponse(respuesta)
        
        except Exception as e:
            logger.error(f"Error en ApiMetricasView: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class ApiConversacionesDiariaView(View):
    """API específica para gráfico de conversaciones diarias"""
    
    def get(self, request):
        """Devuelve datos para el gráfico de conversaciones por día"""
        try:
            dias = int(request.GET.get('dias', 7))
            datos = MetricasService.get_conversaciones_por_dia(dias)
            
            return JsonResponse({
                'status': 'success',
                'data': datos
            })
        
        except Exception as e:
            logger.error(f"Error en ApiConversacionesDiariaView: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class ApiRangosIngresosView(View):
    """API específica para distribución de rangos de ingresos"""
    
    def get(self, request):
        """Devuelve distribución de rangos de ingresos"""
        try:
            datos = MetricasService.get_distribucion_rangos_ingresos()
            
            return JsonResponse({
                'status': 'success',
                'data': datos
            })
        
        except Exception as e:
            logger.error(f"Error en ApiRangosIngresosView: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class ApiHipotecaView(View):
    """API específica para estado de hipoteca"""
    
    def get(self, request):
        """Devuelve distribución de hipotecas SI/NO"""
        try:
            datos = MetricasService.get_estado_hipoteca()
            
            return JsonResponse({
                'status': 'success',
                'data': datos
            })
        
        except Exception as e:
            logger.error(f"Error en ApiHipotecaView: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class ApiEmbudoView(View):
    """API específica para el embudo de estados"""
    
    def get(self, request):
        """Devuelve datos del embudo de estados de leads"""
        try:
            datos = MetricasService.get_embudo_estados()
            
            return JsonResponse({
                'status': 'success',
                'data': datos
            })
        
        except Exception as e:
            logger.error(f"Error en ApiEmbudoView: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class WebhookMakeView(View):
    """Webhook para recibir datos desde Make Automation"""
    
    def post(self, request):
        """Procesa datos enviados desde Make"""
        try:
            # Parsear JSON del request
            data = json.loads(request.body)
            
            # Validar headers de seguridad (opcional)
            auth_header = request.headers.get('Authorization')
            source_header = request.headers.get('X-Carlos-Source')
            
            if source_header != 'make-automation':
                return JsonResponse({
                    'status': 'error',
                    'message': 'Fuente no autorizada'
                }, status=401)
            
            # Procesar datos
            resultado = WebhookService.procesar_webhook(data)
            
            return JsonResponse(resultado)
        
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'JSON inválido'
            }, status=400)
        
        except Exception as e:
            logger.error(f"Error en WebhookMakeView: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class ApiEstadisticasView(View):
    """API para estadísticas generales del sistema"""
    
    def get(self, request):
        """Devuelve estadísticas generales"""
        try:
            sheets_service = GoogleSheetsService()
            datos = sheets_service.get_all_data()
            
            # Calcular estadísticas
            total_registros = len(datos)
            registros_hoy = len([d for d in datos if 'FECHA_HILO' in d])  # Simplificado
            
            # Distribución por segmentos
            segmentos = {}
            for registro in datos:
                segmento = registro.get('CLIENTE_SEGMENTO_LABORAL', 'No definido')
                segmentos[segmento] = segmentos.get(segmento, 0) + 1
            
            # Distribución por entidades
            entidades = {}
            for registro in datos:
                entidad = registro.get('MEJOR_OPCION_ENTIDAD', 'No definida')
                if entidad and entidad != 'No definida':
                    entidades[entidad] = entidades.get(entidad, 0) + 1
            
            respuesta = {
                'status': 'success',
                'data': {
                    'total_registros': total_registros,
                    'registros_hoy': registros_hoy,
                    'distribucion_segmentos': segmentos,
                    'distribucion_entidades': entidades,
                    'google_sheet_info': {
                        'nombre': 'Datamart_GrupoRG_CarlosAI',
                        'hoja': 'Datamart_GrupoRG',
                        'campos': len(sheets_service.fields)
                    }
                }
            }
            
            return JsonResponse(respuesta)
        
        except Exception as e:
            logger.error(f"Error en ApiEstadisticasView: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


# Importar timezone para las vistas
from django.utils import timezone


@require_http_methods(["GET"])
def health_check(request):
    """Health check para verificar que el sistema funciona"""
    try:
        # Verificar conexión a Google Sheets
        sheets_service = GoogleSheetsService()
        sheets_ok = sheets_service.connect()
        
        return JsonResponse({
            'status': 'healthy',
            'timestamp': timezone.now().isoformat(),
            'services': {
                'google_sheets': 'ok' if sheets_ok else 'error',
                'database': 'ok',
                'django': 'ok'
            },
            'version': '1.0.0-produccion'
        })
    
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=500)
