"""
Modelos para Carlos AI Dashboard - PRODUCCIÓN
Conectado a Google Sheets: Datamart_GrupoRG_CarlosAI
"""

from django.db import models
from django.utils import timezone
import json


class GoogleSheetsCache(models.Model):
    """Cache de datos del Google Sheet para optimizar consultas"""
    
    cache_key = models.CharField(max_length=200, unique=True)
    data = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    expires_at = models.DateTimeField()
    
    class Meta:
        verbose_name = 'Cache Google Sheets'
        verbose_name_plural = 'Cache Google Sheets'
    
    def __str__(self):
        return f"Cache: {self.cache_key}"
    
    def is_expired(self):
        return timezone.now() > self.expires_at


class MetricasDiarias(models.Model):
    """Métricas diarias calculadas del sistema Carlos AI"""
    
    fecha = models.DateField(unique=True)
    total_conversaciones = models.IntegerField(default=0)
    conversaciones_completadas = models.IntegerField(default=0)
    conversaciones_derivadas = models.IntegerField(default=0)
    conversaciones_abandonadas = models.IntegerField(default=0)
    
    # Métricas de leads
    leads_frios = models.IntegerField(default=0)
    leads_tibios = models.IntegerField(default=0)
    leads_calientes = models.IntegerField(default=0)
    
    # Métricas de tiempo
    tiempo_promedio_minutos = models.FloatField(default=0.0)
    interacciones_promedio = models.FloatField(default=0.0)
    
    # Tasa de conversión
    tasa_conversion = models.FloatField(default=0.0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Métricas Diarias'
        verbose_name_plural = 'Métricas Diarias'
        ordering = ['-fecha']
    
    def __str__(self):
        return f"Métricas {self.fecha}: {self.total_conversaciones} conversaciones"


class ConfiguracionSistema(models.Model):
    """Configuración del sistema Carlos AI"""
    
    clave = models.CharField(max_length=100, unique=True)
    valor = models.TextField()
    descripcion = models.TextField(blank=True)
    activo = models.BooleanField(default=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Configuración Sistema'
        verbose_name_plural = 'Configuraciones Sistema'
    
    def __str__(self):
        return f"{self.clave}: {self.valor[:50]}"
    
    def get_valor_json(self):
        """Intenta parsear el valor como JSON"""
        try:
            return json.loads(self.valor)
        except:
            return self.valor


class LogEventos(models.Model):
    """Log de eventos del sistema para debugging"""
    
    NIVEL_CHOICES = [
        ('INFO', 'Info'),
        ('WARNING', 'Warning'),
        ('ERROR', 'Error'),
        ('DEBUG', 'Debug'),
    ]
    
    nivel = models.CharField(max_length=10, choices=NIVEL_CHOICES)
    evento = models.CharField(max_length=200)
    descripcion = models.TextField()
    datos_adicionales = models.JSONField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Log Evento'
        verbose_name_plural = 'Log Eventos'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.nivel}: {self.evento}"
