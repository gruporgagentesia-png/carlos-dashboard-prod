"""
URLs para la aplicación dashboard - PRODUCCIÓN
"""

from django.urls import path
from . import views

app_name = 'dashboard'

urlpatterns = [
    # Vista principal
    path('', views.DashboardView.as_view(), name='home'),
    
    # APIs para datos en tiempo real
    path('api/metricas/', views.ApiMetricasView.as_view(), name='api_metricas'),
    path('api/conversaciones-diarias/', views.ApiConversacionesDiariaView.as_view(), name='api_conversaciones_diarias'),
    path('api/rangos-ingresos/', views.ApiRangosIngresosView.as_view(), name='api_rangos_ingresos'),
    path('api/hipoteca/', views.ApiHipotecaView.as_view(), name='api_hipoteca'),
    path('api/embudo/', views.ApiEmbudoView.as_view(), name='api_embudo'),
    path('api/estadisticas/', views.ApiEstadisticasView.as_view(), name='api_estadisticas'),
    
    # Webhook para recibir datos de Make
    path('webhook/make/', views.WebhookMakeView.as_view(), name='webhook_make'),
    
    # Health check
    path('health/', views.health_check, name='health_check'),
]
