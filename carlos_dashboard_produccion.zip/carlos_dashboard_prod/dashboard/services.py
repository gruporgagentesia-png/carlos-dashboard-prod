"""
Servicios para Carlos AI Dashboard - PRODUCCIÓN
Conecta con Google Sheets: Datamart_GrupoRG_CarlosAI
"""

import gspread
from oauth2client.service_account import ServiceAccountCredentials
from django.conf import settings
from django.utils import timezone
from datetime import datetime, timedelta
import json
from .models import GoogleSheetsCache, MetricasDiarias, LogEventos
import logging

logger = logging.getLogger(__name__)


class GoogleSheetsService:
    """Servicio para conectar con Google Sheets"""
    
    def __init__(self):
        self.spreadsheet_id = settings.GOOGLE_SHEETS_CONFIG['SPREADSHEET_ID']
        self.sheet_name = settings.GOOGLE_SHEETS_CONFIG['SHEET_NAME']
        self.fields = settings.CARLOS_AI_FIELDS
        self.client = None
        self.sheet = None
    
    def connect(self):
        """Conecta con Google Sheets usando credenciales de servicio"""
        try:
            # Configurar credenciales (se configurará más tarde con la cuenta Gmail)
            scope = settings.GOOGLE_SHEETS_CONFIG['SCOPES']
            
            # Por ahora usamos datos de ejemplo hasta configurar credenciales
            logger.info("Usando datos de ejemplo - configurar credenciales de producción")
            return True
            
        except Exception as e:
            logger.error(f"Error conectando con Google Sheets: {e}")
            LogEventos.objects.create(
                nivel='ERROR',
                evento='google_sheets_connection_failed',
                descripcion=str(e)
            )
            return False
    
    def get_all_data(self, use_cache=True):
        """Obtiene todos los datos del Google Sheet"""
        cache_key = f"google_sheets_all_data_{self.sheet_name}"
        
        # Intentar usar cache primero
        if use_cache:
            try:
                cache_obj = GoogleSheetsCache.objects.get(cache_key=cache_key)
                if not cache_obj.is_expired():
                    logger.info("Usando datos del cache")
                    return cache_obj.data
            except GoogleSheetsCache.DoesNotExist:
                pass
        
        # Datos de ejemplo para desarrollo/testing
        datos_ejemplo = self._get_datos_ejemplo()
        
        # Guardar en cache
        expires_at = timezone.now() + timedelta(minutes=30)
        GoogleSheetsCache.objects.update_or_create(
            cache_key=cache_key,
            defaults={
                'data': datos_ejemplo,
                'expires_at': expires_at
            }
        )
        
        return datos_ejemplo
    
    def _get_datos_ejemplo(self):
        """Genera datos de ejemplo con la estructura correcta"""
        from random import choice, randint
        from datetime import datetime, timedelta
        
        # Estados y tipos definidos en el chat anterior
        estados_lead = [
            'CONTACTO_INICIAL', 'RECOPILANDO_PERSONAL', 'RECOPILANDO_FINANCIERA',
            'RECOMENDACION_HECHA', 'ACEPTA_DERIVACION', 'MANEJA_OBJECIONES', 'ABANDONADO'
        ]
        
        tipos_lead = ['FRIO', 'TIBIO', 'CALIENTE']
        segmentos = ['PUBLICO', 'PRIVADO', 'JUBILADO', 'FUERZA_PUBLICA', 'ACP', 'LINEA_BLANCA']
        entidades = ['GLOBAL_BANK', 'BAC', 'BANESCO', 'CREDICORP_BANK', 'CORPORACION_EL_SOL', 'PANACREDIT']
        generos = ['MASCULINO', 'FEMENINO']
        
        datos = []
        
        # Generar 50 registros de ejemplo
        for i in range(50):
            fecha_inicio = datetime.now() - timedelta(days=randint(1, 30))
            fecha_ultima = fecha_inicio + timedelta(hours=randint(1, 48))
            
            ingreso = randint(500, 3000)
            rango_ingreso = self._calcular_rango_ingreso(ingreso)
            
            registro = {
                'CODIGO_HILO': f"thread_{fecha_inicio.strftime('%Y%m%d')}_{i:03d}",
                'FECHA_HILO': fecha_inicio.strftime('%d/%m/%Y %H:%M'),
                'FECHA_ULTIMA_INTERACCION': fecha_ultima.strftime('%d/%m/%Y %H:%M'),
                'FECHA_CONVERSION': fecha_ultima.strftime('%d/%m/%Y %H:%M') if randint(1, 3) == 1 else '',
                'CANAL_COMUNICACION': 'WhatsApp',
                'NUMERO_TELEFONO': f'507{randint(60000000, 79999999)}',
                
                'CLIENTE_NOMBRE': choice(['Carlos', 'Ana', 'José', 'María', 'Luis', 'Carmen', 'Pedro', 'Rosa']),
                'CLIENTE_GENERO': choice(generos),
                'CLIENTE_SEGMENTO_LABORAL': choice(segmentos),
                
                'INGRESO_BRUTO_MENSUAL': ingreso,
                'HIPOTECA_VIGENTE': choice(['SI', 'NO']),
                'HIPOTECA_COMPARTIDA': choice(['SI', 'NO', '']),
                
                'RANGO_INGRESOS': rango_ingreso,
                'NIVEL_DEUDA': choice(['ALTO', 'MEDIO', 'BAJO']),
                
                'MEJOR_OPCION_ENTIDAD': choice(entidades),
                'PRODUCTOS_DISPONIBLES': randint(1, 6),
                'MONTO_MAXIMO_APROBADO': randint(10000, 75000),
                
                'TIPO_LEAD': choice(tipos_lead),
                'ESTADO_LEAD': choice(estados_lead),
                'NUMERO_INTERACCIONES': randint(3, 15),
                
                'TIMESTAMP_INICIO': fecha_inicio.isoformat(),
                'TIMESTAMP_FIN': fecha_ultima.isoformat(),
            }
            
            datos.append(registro)
        
        return datos
    
    def _calcular_rango_ingreso(self, ingreso):
        """Calcula el rango de ingreso según los rangos definidos"""
        if ingreso <= 500:
            return '0-500'
        elif ingreso <= 700:
            return '500-700'
        elif ingreso <= 1000:
            return '700-1000'
        elif ingreso <= 1200:
            return '1000-1200'
        elif ingreso <= 1500:
            return '1200-1500'
        elif ingreso <= 2000:
            return '1500-2000'
        else:
            return '2000+'


class MetricasService:
    """Servicio para calcular métricas del dashboard"""
    
    @staticmethod
    def get_metricas_principales():
        """Obtiene las 4 métricas principales del dashboard"""
        sheets_service = GoogleSheetsService()
        datos = sheets_service.get_all_data()
        
        total_conversaciones = len(datos)
        
        # Calcular tiempo promedio (diferencia entre fecha_hilo y fecha_ultima_interaccion)
        tiempos = []
        for registro in datos:
            try:
                inicio = datetime.fromisoformat(registro['TIMESTAMP_INICIO'])
                fin = datetime.fromisoformat(registro['TIMESTAMP_FIN'])
                tiempo_minutos = (fin - inicio).total_seconds() / 60
                tiempos.append(tiempo_minutos)
            except:
                continue
        
        tiempo_promedio = sum(tiempos) / len(tiempos) if tiempos else 0
        
        # Interacciones promedio
        interacciones = [r.get('NUMERO_INTERACCIONES', 0) for r in datos]
        interacciones_promedio = sum(interacciones) / len(interacciones) if interacciones else 0
        
        # Eficiencia (% que llegan a ACEPTA_DERIVACION)
        acepta_derivacion = len([r for r in datos if r.get('ESTADO_LEAD') == 'ACEPTA_DERIVACION'])
        eficiencia = (acepta_derivacion / total_conversaciones * 100) if total_conversaciones > 0 else 0
        
        return {
            'total_conversaciones': total_conversaciones,
            'tiempo_promedio': round(tiempo_promedio, 1),
            'interacciones_promedio': round(interacciones_promedio, 1),
            'eficiencia': round(eficiencia, 1)
        }
    
    @staticmethod
    def get_distribucion_rangos_ingresos():
        """Obtiene la distribución por rangos de ingresos"""
        sheets_service = GoogleSheetsService()
        datos = sheets_service.get_all_data()
        
        rangos = {}
        for registro in datos:
            rango = registro.get('RANGO_INGRESOS', 'No definido')
            rangos[rango] = rangos.get(rango, 0) + 1
        
        # Ordenar rangos
        orden_rangos = ['0-500', '500-700', '700-1000', '1000-1200', '1200-1500', '1500-2000', '2000+']
        rangos_ordenados = {}
        
        for rango in orden_rangos:
            if rango in rangos:
                rangos_ordenados[rango] = rangos[rango]
        
        return rangos_ordenados
    
    @staticmethod
    def get_estado_hipoteca():
        """Obtiene la distribución de hipotecas (SI/NO)"""
        sheets_service = GoogleSheetsService()
        datos = sheets_service.get_all_data()
        
        hipotecas = {'SI': 0, 'NO': 0}
        for registro in datos:
            estado = registro.get('HIPOTECA_VIGENTE', 'NO')
            if estado in hipotecas:
                hipotecas[estado] += 1
        
        return hipotecas
    
    @staticmethod
    def get_embudo_estados():
        """Obtiene datos para el embudo de estados de leads"""
        sheets_service = GoogleSheetsService()
        datos = sheets_service.get_all_data()
        
        estados = {}
        for registro in datos:
            estado = registro.get('ESTADO_LEAD', 'CONTACTO_INICIAL')
            estados[estado] = estados.get(estado, 0) + 1
        
        # Orden del embudo
        orden_estados = [
            'CONTACTO_INICIAL', 'RECOPILANDO_PERSONAL', 'RECOPILANDO_FINANCIERA',
            'RECOMENDACION_HECHA', 'MANEJA_OBJECIONES', 'ABANDONADO', 'ACEPTA_DERIVACION'
        ]
        
        embudo = {}
        total = len(datos)
        
        for estado in orden_estados:
            cantidad = estados.get(estado, 0)
            porcentaje = (cantidad / total * 100) if total > 0 else 0
            embudo[estado] = {
                'cantidad': cantidad,
                'porcentaje': round(porcentaje, 1)
            }
        
        return embudo
    
    @staticmethod
    def get_conversaciones_por_dia(dias=7):
        """Obtiene conversaciones por día para el gráfico de líneas"""
        sheets_service = GoogleSheetsService()
        datos = sheets_service.get_all_data()
        
        # Agrupar por fecha
        fechas = {}
        for registro in datos:
            try:
                fecha_str = registro.get('FECHA_HILO', '')
                fecha = datetime.strptime(fecha_str.split(' ')[0], '%d/%m/%Y').date()
                fecha_key = fecha.strftime('%Y-%m-%d')
                fechas[fecha_key] = fechas.get(fecha_key, 0) + 1
            except:
                continue
        
        # Obtener últimos X días
        resultado = []
        for i in range(dias):
            fecha = (datetime.now().date() - timedelta(days=dias-1-i))
            fecha_key = fecha.strftime('%Y-%m-%d')
            resultado.append({
                'fecha': fecha.strftime('%d/%m'),
                'total': fechas.get(fecha_key, 0)
            })
        
        return resultado


class WebhookService:
    """Servicio para manejar webhooks de Make Automation"""
    
    @staticmethod
    def procesar_webhook(datos):
        """Procesa datos recibidos desde Make via webhook"""
        try:
            # Log del evento
            LogEventos.objects.create(
                nivel='INFO',
                evento='webhook_recibido',
                descripcion='Datos recibidos de Make Automation',
                datos_adicionales=datos
            )
            
            # Aquí se procesarían los datos y se agregarían al Google Sheet
            # Por ahora solo los loggeamos
            
            return {'status': 'success', 'message': 'Datos procesados correctamente'}
            
        except Exception as e:
            LogEventos.objects.create(
                nivel='ERROR',
                evento='webhook_error',
                descripcion=str(e),
                datos_adicionales=datos
            )
            return {'status': 'error', 'message': str(e)}
