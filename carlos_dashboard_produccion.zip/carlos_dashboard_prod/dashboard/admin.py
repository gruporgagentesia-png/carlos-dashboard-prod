"""
Configuración del admin para Carlos AI Dashboard - PRODUCCIÓN
"""

from django.contrib import admin
from .models import GoogleSheetsCache, MetricasDiarias, ConfiguracionSistema, LogEventos


@admin.register(GoogleSheetsCache)
class GoogleSheetsCacheAdmin(admin.ModelAdmin):
    list_display = ('cache_key', 'created_at', 'updated_at', 'expires_at', 'is_expired')
    list_filter = ('created_at', 'expires_at')
    search_fields = ('cache_key',)
    readonly_fields = ('created_at', 'updated_at')
    
    def is_expired(self, obj):
        return obj.is_expired()
    is_expired.boolean = True
    is_expired.short_description = '¿Expirado?'


@admin.register(MetricasDiarias)
class MetricasDiariasAdmin(admin.ModelAdmin):
    list_display = (
        'fecha', 'total_conversaciones', 'conversaciones_completadas',
        'tasa_conversion', 'tiempo_promedio_minutos'
    )
    list_filter = ('fecha', 'created_at')
    search_fields = ('fecha',)
    readonly_fields = ('created_at', 'updated_at')
    date_hierarchy = 'fecha'


@admin.register(ConfiguracionSistema)
class ConfiguracionSistemaAdmin(admin.ModelAdmin):
    list_display = ('clave', 'valor', 'activo', 'updated_at')
    list_filter = ('activo', 'created_at')
    search_fields = ('clave', 'descripcion')
    readonly_fields = ('created_at', 'updated_at')


@admin.register(LogEventos)
class LogEventosAdmin(admin.ModelAdmin):
    list_display = ('nivel', 'evento', 'descripcion', 'created_at')
    list_filter = ('nivel', 'created_at')
    search_fields = ('evento', 'descripcion')
    readonly_fields = ('created_at',)
    date_hierarchy = 'created_at'
    
    # Mostrar solo los últimos 1000 registros para performance
    def get_queryset(self, request):
        return super().get_queryset(request)[:1000]
