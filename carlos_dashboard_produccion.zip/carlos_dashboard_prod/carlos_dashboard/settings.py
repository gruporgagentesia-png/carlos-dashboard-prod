"""
Django settings for carlos_dashboard project - PRODUCCIÓN
Configurado para Google Sheets: Datamart_GrupoRG_CarlosAI
"""

import os
from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-carlos-ai-prod-2025-grupoRG-dashboard-key'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = ['*']

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'dashboard',
    'corsheaders',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'carlos_dashboard.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'carlos_dashboard.wsgi.application'

# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
LANGUAGE_CODE = 'es-es'
TIME_ZONE = 'America/Panama'
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_DIRS = [
    BASE_DIR / 'static',
]

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# CORS settings
CORS_ALLOW_ALL_ORIGINS = True
CORS_ALLOW_CREDENTIALS = True

# Google Sheets Configuration - PRODUCCIÓN
GOOGLE_SHEETS_CONFIG = {
    'SPREADSHEET_ID': '1NJaT0XrI1roCg6U_tLSXpnyl_VJ2NPd30RdFQWF_g7A',
    'SHEET_NAME': 'Datamart_GrupoRG',
    'SPREADSHEET_NAME': 'Datamart_GrupoRG_CarlosAI',
    'CREDENTIALS_FILE': 'google_credentials.json',  # Se configurará más tarde
    'SCOPES': [
        'https://www.googleapis.com/auth/spreadsheets.readonly',
        'https://www.googleapis.com/auth/drive.readonly'
    ]
}

# Configuración de campos del Google Sheet
CARLOS_AI_FIELDS = {
    # Identificadores (Azul claro)
    'CODIGO_HILO': 'A',
    'FECHA_HILO': 'B', 
    'FECHA_ULTIMA_INTERACCION': 'C',
    'FECHA_CONVERSION': 'D',
    'CANAL_COMUNICACION': 'E',
    'NUMERO_TELEFONO': 'F',
    
    # Información del Cliente (Verde claro)
    'CLIENTE_NOMBRE': 'G',
    'CLIENTE_NUMERO_DOCUMENTO': 'H',
    'CLIENTE_EDAD': 'I',
    'CLIENTE_TELEFONO': 'J',
    'CLIENTE_EMAIL': 'K',
    'CLIENTE_GENERO': 'L',
    'CLIENTE_SEGMENTO_LABORAL': 'M',
    
    # Información Financiera (Rosa claro)
    'INGRESO_BRUTO_MENSUAL': 'N',
    'HIPOTECA_VIGENTE': 'O',
    'HIPOTECA_COMPARTIDA': 'P',
    'MONTO_HIPOTECA_MENSUAL': 'Q',
    'OTRAS_DEUDAS_MENSUAL': 'R',
    
    # Campos Calculados (Amarillo claro)
    'DEUDA_TOTAL_MENSUAL': 'S',
    'CAPACIDAD_PAGO_DISPONIBLE': 'T',
    'NIVEL_DEUDA': 'U',
    'RANGO_INGRESOS': 'V',
    
    # Resultado de Evaluación (Ciruela)
    'CALIFICACION_CREDITICIA': 'W',
    'ENTIDADES_CALIFICADAS': 'X',
    'PRODUCTOS_DISPONIBLES': 'Y',
    'MEJOR_OPCION_ENTIDAD': 'Z',
    'MEJOR_OPCION_PRODUCTO': 'AA',
    'MONTO_MAXIMO_APROBADO': 'AB',
    'PLAZO_MAXIMO_MESES': 'AC',
    'TASA_INTERES_ESTIMADA': 'AD',
    
    # Clasificación de Lead (Khaki)
    'TIPO_LEAD': 'AE',
    'ESTADO_LEAD': 'AF',
    'RESUMEN_EVALUACION': 'AG',
    
    # Conversación Completa (Mocasín)
    'CHAT_COMPLETO': 'AH',
    'CLASIFICACION_IA': 'AI',
    
    # Campos Técnicos (Gris claro)
    'TIMESTAMP_INICIO': 'AJ',
    'TIMESTAMP_FIN': 'AK',
    'NUMERO_INTERACCIONES': 'AL',
    'ETAPA_EVALUACION': 'AM',
    'VERSION_SISTEMA': 'AN'
}

# Configuración de logging
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'INFO',
    },
}
