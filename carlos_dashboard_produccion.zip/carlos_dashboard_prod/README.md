# 🎯 Carlos AI Dashboard - Producción

Dashboard profesional para monitorear en tiempo real las métricas del sistema Carlos AI de evaluación crediticia.

## 📊 Características

- **Dashboard en tiempo real** con métricas actualizadas automáticamente
- **Conexión directa** a Google Sheets: `Datamart_GrupoRG_CarlosAI`
- **Gráficos interactivos** con Chart.js
- **Embudo de conversión** proporcional y estilizado
- **APIs REST** para integración con Make Automation
- **Diseño responsivo** para móviles y tablets

## 🏗️ Arquitectura

```
Make Automation → Google Sheets → Django Dashboard
                     ↓
               Datamart_GrupoRG_CarlosAI
               └── Datamart_GrupoRG (45 campos)
```

## 📋 Métricas Principales

1. **Total Conversaciones**: Cantidad total de leads procesados
2. **Tiempo Promedio**: Diferencia entre fecha_ultima_interaccion y fecha_hilo
3. **Interacciones Promedio**: Promedio del campo numero_interacciones
4. **Eficiencia**: % de leads que llegan a ACEPTA_DERIVACION

## 🎨 Visualizaciones

### Gráficos
- **Líneas**: Conversaciones generadas por día
- **Dona**: Distribución por rangos de ingresos (0-500, 500-700, 700-1000, etc.)

### Tablas
- **Estado Hipoteca**: SI/NO usando campo Hipoteca_Vigente
- **Resumen Sistema**: Estados, campos, entidades, segmentos

### Embudo de Estados
1. CONTACTO_INICIAL
2. RECOPILANDO_PERSONAL
3. RECOPILANDO_FINANCIERA
4. RECOMENDACION_HECHA
5. MANEJA_OBJECIONES
6. ABANDONADO
7. ACEPTA_DERIVACION

## 🚀 Despliegue en Easypanel

### Paso 1: Subir Código
1. Comprimir toda la carpeta en `carlos_dashboard_prod.zip`
2. Subir a Easypanel en el servicio `carlos-dashboard-prod`
3. Easypanel detectará automáticamente el Dockerfile

### Paso 2: Configuración
- **Puerto**: 8000 (automático)
- **Variables de entorno**: Se configuran en Easypanel
- **Base de datos**: SQLite incluida

## 🔗 URLs Disponibles

```
/                           - Dashboard principal
/api/metricas/             - Todas las métricas en JSON
/api/conversaciones-diarias/ - Gráfico de conversaciones
/api/rangos-ingresos/      - Distribución de ingresos
/api/hipoteca/             - Estado de hipotecas
/api/embudo/               - Datos del embudo
/webhook/make/             - Recibir datos de Make
/health/                   - Health check
/admin/                    - Panel administrativo
```

## 🔧 APIs REST

### GET /api/metricas/
Devuelve todas las métricas del dashboard:

```json
{
  "status": "success",
  "data": {
    "metricas_principales": {
      "total_conversaciones": 47,
      "tiempo_promedio": 24.5,
      "interacciones_promedio": 8.2,
      "eficiencia": 12.3
    },
    "rangos_ingresos": {
      "0-500": 5,
      "500-700": 12,
      "700-1000": 15
    },
    "estado_hipoteca": {
      "SI": 23,
      "NO": 24
    },
    "embudo_estados": {
      "CONTACTO_INICIAL": {"cantidad": 24, "porcentaje": 51.1}
    },
    "conversaciones_por_dia": [
      {"fecha": "15/01", "total": 8},
      {"fecha": "16/01", "total": 12}
    ]
  }
}
```

### POST /webhook/make/
Recibe datos de Make Automation:

```json
{
  "chat_id": "thread_20250117_001",
  "segmento_laboral": "PUBLICO",
  "ingreso_bruto": 1200,
  "estado_lead": "ACEPTA_DERIVACION",
  "timestamp": "2025-01-17T10:30:00Z"
}
```

## 📈 Integración con Make

### Headers Requeridos
```
Content-Type: application/json
Authorization: Bearer carlos-ai-webhook-secret-2025
X-Carlos-Source: make-automation
```

### Ejemplo de Envío desde Make
```javascript
// En Make HTTP Request Module
{
  "url": "https://tu-dominio.com/webhook/make/",
  "method": "POST",
  "headers": {
    "Content-Type": "application/json",
    "X-Carlos-Source": "make-automation"
  },
  "body": {
    "chat_id": "{{chat_id}}",
    "estado_lead": "{{estado}}",
    "ingreso_bruto": {{ingreso}}
  }
}
```

## 🎯 Estados de Lead Definidos

| Estado | Descripción |
|--------|-------------|
| CONTACTO_INICIAL | Solo saludos básicos |
| RECOPILANDO_PERSONAL | Datos personales entregados |
| RECOPILANDO_FINANCIERA | Datos financieros entregados |
| RECOMENDACION_HECHA | Cliente pre-califica |
| MANEJA_OBJECIONES | Cliente hace preguntas |
| ABANDONADO | Cliente desiste |
| ACEPTA_DERIVACION | Cliente acepta derivación |

## 🔄 Actualización Automática

- **Frontend**: Se actualiza cada 5 minutos automáticamente
- **Cache**: Datos se cachean por 30 minutos
- **Google Sheets**: Se consulta bajo demanda con cache inteligente

## 🛠️ Estructura del Proyecto

```
carlos_dashboard_prod/
├── carlos_dashboard/          # Configuración Django
│   ├── __init__.py
│   ├── settings.py           # Configuración principal
│   ├── urls.py              # URLs principales
│   └── wsgi.py              # WSGI para producción
├── dashboard/               # Aplicación principal
│   ├── models.py           # Modelos de datos
│   ├── views.py            # Vistas y APIs
│   ├── services.py         # Lógica de negocio
│   ├── urls.py             # URLs de la app
│   └── admin.py            # Configuración admin
├── templates/              # Templates HTML
│   └── dashboard/
│       └── dashboard.html  # Template principal
├── static/                 # Archivos estáticos
├── requirements.txt        # Dependencias Python
├── Dockerfile             # Configuración Docker
└── README.md              # Este archivo
```

## 🎨 Tecnologías Utilizadas

- **Backend**: Django 4.2.7
- **Frontend**: Bootstrap 5 + Chart.js
- **Base de Datos**: SQLite (incluida)
- **APIs**: Google Sheets API
- **Despliegue**: Docker + Easypanel
- **Integración**: Make Automation webhooks

## 📊 Google Sheets Configuración

**Hoja**: Datamart_GrupoRG_CarlosAI  
**Pestaña**: Datamart_GrupoRG  
**Campos**: 45 campos organizados en 8 categorías  
**ID**: `1NJaT0XrI1roCg6U_tLSXpnyl_VJ2NPd30RdFQWF_g7A`

## 🎯 Próximos Pasos

1. **Configurar credenciales Google**: Para acceso real a Google Sheets
2. **Configurar webhooks Make**: Para recibir datos en tiempo real
3. **Personalizar métricas**: Según necesidades específicas
4. **Agregar alertas**: Para métricas críticas
5. **Dashboard móvil**: Optimizaciones adicionales

## 📞 Soporte

Para soporte técnico o modificaciones:
- Dashboard funcionando en: `http://72.61.6.41:PUERTO`
- Health check: `/health/`
- Admin panel: `/admin/`

---

**🚀 Carlos AI Dashboard v1.0.0 - Producción**  
*Sistema de Monitoreo para Evaluación Crediticia Automatizada*
